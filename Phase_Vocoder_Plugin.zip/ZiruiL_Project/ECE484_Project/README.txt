ECE484_Project:
	\Document: Report and slides.
	\Plugin: Our Plugin "Project.vst3".
	\Plugin Host: The online plugin Host with audio file player.
	\Sound_Tracks: Sample sound tracks for testing.
	\VS_solution: Project solution and source code.

Plugin Using Instructions: (You may need to have JUCE and Visual Studio 2017 installed on your computer to run this plugin)
	1. Save and Extract the folder 'ECE484_Project'. 
	2. Go into the folder labeled 'Plugin_Host' and run 'Plugin Host.exe'
	3. Within the Plugin Host application, go to 'Options' -> 'Edit the List of available plug-ins'
	4. Within the new window, at the bottom there should be another options button. 'Options' -> 'Scan for new or updated VST3 plug-ins'
	5. There will be a default location listed for the program. Select this path, and hit the 'change' button
	6. Set path to the folder containing this project, the path is 'ECE484_Project\Plugin'
	7. Select the updated path and click 'Scan' and the application should add the VST3 plugin 'Project' to the list
	8. Return to the main screen of the application. the 'Midi Input' and 'Audio Input' bubbles can be right clicked and deleted, they are not needed
	9. Right click anywhere within the main screen and select 'Audiofile Player (Internal)'
	10. Right click on the new Audiofile Player bubble, and click 'Configure Audio I/O', hit the little '+' to add a second track
	11. Now you can double click the 'Audiofile Player' bubble and load in 2 tracks, there are 2 tracks already provided in the project folder 'Sound_Tracks'
	12. Now right click anywhere within the main screen again and the 'Project' plugin should appear under 'yourcompany'
	13. Connect the 2 green pins from the 'Audiofile Player' to the 2 green pins on 'Project', and the 2 blue to blue
	14. Each of the 2 bottom green pins from 'Project' will connect to 'Audio Output' respectively.
	15. (Audio Output I/O settings should default to your speakers, but you can change the output device by right clicking on 'Audio Output' and going to 'Configure Audio I/O')
	16. If you want to have mono inputs, right click the 'Project' plugin, and uncheck the 'Enable' of Bus Input 1.	
	17. You are now ready to use the plugin! Double click 'Audiofile Player' to bring up playback controls for the tracks, and double click 'Project' to change the mutation settings of the phase vocoder plugin


Setting Environment Path for Running the VS Solution:
	1. In the 'VS_solution' directory, extract the zip folder called 'ECE-484-release.zip'
	2. Go into the 'ECE-484-release' directory, create a new folder called 'juce-5.4.1-windows'
	3. Put the downloaded JUCE and VST-SDK here
	4. Go into the 'JUCE' directory, double click the 'Projucer.exe'
	5. Click 'File' and open the 'Project.jucer' under the 'ECE-484-rc2' directory, open it in the VisualStudio 
		OR 
	   You can open the solution "ECE484_Project\VS_solution\ECE-484-release\ECE-484-rc2\Builds\VisualStudio2017\Project.sln" directly
	6. Build solution
	7. Our plugin 'Project.vst3' is under the path "ECE484_Project\VS_solution\ECE-484-release\ECE-484-rc2\Builds\VisualStudio2017\x64\Debug\VST3"
	8. Oue plugin application 'Project.exe' is under the path "ECE484_Project\VS_solution\ECE-484-release\ECE-484-rc2\Builds\VisualStudio2017\x64\Debug\Standalone Plugin"
	9. Follow the previous plugin using instruction to test our plugin.
